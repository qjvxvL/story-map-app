import AuthRepository from "../../data/auth-repository.js";
import AuthHelper from "../../utils/auth-helper.js";

class Navbar {
  static render() {
    const isAuthenticated = AuthRepository.isAuthenticated();
    const user = AuthRepository.getUser();

    if (!isAuthenticated) {
      return `
        <div class="navbar-container">
          <div class="navbar-brand">
            <h1>Story Map</h1>
          </div>
        </div>
      `;
    }

    return `
      <div class="navbar-container">
        <div class="navbar-brand">
          <h1>Story Map</h1>
        </div>
        <ul class="navbar-menu" role="menubar">
          <li role="none">
            <a href="#/home" class="nav-link" role="menuitem" tabindex="0">
              Home
            </a>
          </li>
          <li role="none">
            <a href="#/add-story" class="nav-link" role="menuitem" tabindex="0">
              Add Story
            </a>
          </li>
          <li role="none">
            <span class="user-info">${user?.name || "User"}</span>
          </li>
          <li role="none">
            <button id="logout-btn" class="btn-logout" aria-label="Logout" tabindex="0">
              Logout
            </button>
          </li>
        </ul>
        <button class="navbar-toggle" id="navbar-toggle" aria-label="Toggle navigation" aria-expanded="false">
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    `;
  }

  static afterRender() {
    const logoutBtn = document.querySelector("#logout-btn");
    const navbarToggle = document.querySelector("#navbar-toggle");
    const navbarMenu = document.querySelector(".navbar-menu");

    if (logoutBtn) {
      logoutBtn.addEventListener("click", () => {
        AuthHelper.logout();
      });

      logoutBtn.addEventListener("keypress", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          AuthHelper.logout();
        }
      });
    }

    if (navbarToggle && navbarMenu) {
      navbarToggle.addEventListener("click", () => {
        navbarMenu.classList.toggle("active");
        const isExpanded = navbarMenu.classList.contains("active");
        navbarToggle.setAttribute("aria-expanded", isExpanded);
      });
    }

    // Set active link
    const currentHash = window.location.hash;
    const navLinks = document.querySelectorAll(".nav-link");
    navLinks.forEach((link) => {
      if (link.getAttribute("href") === currentHash) {
        link.classList.add("active");
      } else {
        link.classList.remove("active");
      }
    });
  }
}

export default Navbar;
