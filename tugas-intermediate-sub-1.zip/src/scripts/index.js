// CSS imports
import "../styles/style.css";
import "../styles/responsive.css";
import "../styles/transitions.css";
import App from "./routes/routes.js";

const app = new App({
  content: document.querySelector("#page-content"),
  navbar: document.querySelector("#navbar"),
});

window.addEventListener("hashchange", () => {
  app.renderPage();
});

window.addEventListener("load", () => {
  app.renderPage();
});

window.addEventListener("DOMContentLoaded", () => {
  // Initialize view transitions if supported
  if (!document.startViewTransition) {
    console.log("View Transitions API not supported");
  }
});
